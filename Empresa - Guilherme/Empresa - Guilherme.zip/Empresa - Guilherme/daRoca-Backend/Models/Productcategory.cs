public class ProductCategory{
    public required int ProductCategoryId { get; set; }
    public required string Name { get; set; }
}