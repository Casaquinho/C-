using System.Runtime.Intrinsics.X86;
using Microsoft.EntityFrameworkCore;

public partial class DatabaseContext : DbContext
{
    public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
    {

    }

    public virtual DbSet<Custumer> Custumer { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //criar a db
        modelBuilder.Entity<Custumer>().HasKey(e => e.CustomerId);
        modelBuilder.Entity<Custumer>().Property(e => e.Name).IsRequired().HasMaxLength(50);
        modelBuilder.Entity<Custumer>().Property(e => e.City).IsRequired().HasMaxLength(30);
        modelBuilder.Entity<Custumer>().Property(e => e.State).IsRequired().HasMaxLength(30);
        modelBuilder.Entity<Custumer>().Property(e => e.Latitude).HasPrecision(11,3).IsRequired();
        modelBuilder.Entity<Custumer>().Property(e => e.Longitude).HasPrecision(11,3).IsRequired();

        modelBuilder.Entity<ProductCategory>().HasKey(e => e.ProductCategoryId);
        modelBuilder.Entity<ProductCategory>().Property(p => p.Name).IsRequired().HasMaxLength(50);

        modelBuilder.Entity<Product>().HasKey(p => p.ProductId);
        modelBuilder.Entity<Product>().Property(p => p.ProductCategoryId).IsRequired();
        modelBuilder.Entity<Product>().Property(p => p.Name).IsRequired().HasMaxLength(50);
        modelBuilder.Entity<Product>().Property(p => p.Price).HasPrecision(10,2).IsRequired();


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}