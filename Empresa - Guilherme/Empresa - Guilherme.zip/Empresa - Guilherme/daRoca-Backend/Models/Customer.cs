using System.ComponentModel.DataAnnotations;
//para ter as primary keys


public class Custumer
{

    public int CustomerId{get;set;}

    public string Name{get;set;}


    public string City{get;set;}


    public string State{get;set;}

    public required decimal Latitude{get;set;}

    public required decimal Longitude{get;set;}




    public Custumer(int customerId, string name, string City, string State, decimal Latitude, decimal Longitude)
    {
        CustomerId = customerId;
        Name = name;
        this.City = City;
        this.State = State;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
    }

}