﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace daRoca_Backend.Migrations
{
    /// <inheritdoc />
    public partial class SecondCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Longitude",
                table: "Custumer");

            migrationBuilder.RenameColumn(
                name: "Latitude",
                table: "Custumer",
                newName: "State");

            migrationBuilder.RenameColumn(
                name: "Email",
                table: "Custumer",
                newName: "City");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Custumer",
                newName: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "State",
                table: "Custumer",
                newName: "Latitude");

            migrationBuilder.RenameColumn(
                name: "City",
                table: "Custumer",
                newName: "Email");

            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "Custumer",
                newName: "Id");

            migrationBuilder.AddColumn<double>(
                name: "Longitude",
                table: "Custumer",
                type: "float",
                maxLength: 100,
                nullable: false,
                defaultValue: 0.0);
        }
    }
}
