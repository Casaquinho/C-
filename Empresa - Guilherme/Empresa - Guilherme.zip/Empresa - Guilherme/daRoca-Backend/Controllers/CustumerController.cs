using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Runtime.CompilerServices;


[Route("/controller")]
[ApiController                                                                                                                                                                                    ]
public class CustumerController:ControllerBase
{                           //context seria o banco de dados (porta, valor etc)
    private readonly DatabaseContext context;

    public CustumerController(DatabaseContext context)
    {
        this.context = context;
    }

    [HttpGet]
                    //n vem em list, ent tem q converter
    public ActionResult<IEnumerable<Custumer>> GetCustumer()
    {
        return context.Custumer.ToList();
    }

    [HttpGet("{id}")]
    public ActionResult<Custumer> GetCustumer(int id)
    {
        var custumer = context.Custumer.Find(id);
        //id pode n existir
        if(custumer == null)
        {
            return NotFound();
        }
        return custumer;
    }

    [HttpPost]
    public ActionResult<Custumer> CreateCustumer(Custumer costumer)
    {
        if(costumer == null)
        {
            return BadRequest();
        }
        this.context.Custumer.Add(costumer);
        //sera usado na prova o save changes (server para adicionar item numa ordem e tendo um maior controle, ex, n da para add produtos sem uma loja, ent se coloca o save changes para garantir q a loja exista(apenas um save changes para q ele mende um pacote com a ordem dos inserts))

        this.context.SaveChanges();

        //retorna o custumer criado
        //CreatedAtAction é um metodo q retorna o status 201 (created) e o link para o custumer criado e o custumer criado
        //poderia retornar um true ou false, mas n é o ideal
        return CreatedAtAction(nameof(GetCustumer), new {id = costumer.CustomerId}, costumer);
    }

    public ActionResult<Custumer> DeleteCustumer(Custumer costumer)
    {
        if(costumer == null)
        {
            return BadRequest();
        }
        var CostumerAchado = this.context.Custumer.Find(costumer.CustomerId);

        if(CostumerAchado == null)
        {
            return NotFound();
        }
        this.context.Custumer.Remove(costumer);
        this.context.SaveChanges();
        return CostumerAchado;
    }



}